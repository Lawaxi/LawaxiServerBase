package net.lawaxi.serverbase.shits;

import net.minecraft.server.network.ServerPlayerEntity;

public class tparequest {

    public ServerPlayerEntity me;
    public ServerPlayerEntity to;
    public boolean mode;//false为tpa true为tpahere
}
