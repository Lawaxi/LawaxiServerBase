package net.lawaxi.serverbase.shits;
/*
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

public class locationinfo {
    public BlockPos position;
    public ServerWorld world;

    private static locationinfo createInfo(ServerWorld world,BlockPos pos)
    {
        locationinfo a = new locationinfo();
        a.position=pos;
        a.world=world;
        return a;
    }

    public static void recordlocation(ServerPlayerEntity player)
    {
        list.playerrecord.set(player.getEntityId(),locationinfo.createInfo(player.getServerWorld(),player.getBlockPos()));
    }
}*/
