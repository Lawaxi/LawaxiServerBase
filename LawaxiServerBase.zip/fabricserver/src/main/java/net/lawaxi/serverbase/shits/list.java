package net.lawaxi.serverbase.shits;

import java.util.ArrayList;

public class list {

    public static ArrayList<tparequest> tparequests = new ArrayList<>();

    //一个并没有做成功的功能：/back
    //public static ArrayList<locationinfo> playerrecord = new ArrayList<>();
}
